#ifndef CLIENTEESTATICA_H_INCLUDED
#define CLIENTEESTATICA_H_INCLUDED

#include <stdio.h>
#include "Funcionario.h"
#include "ListaFuncionarioEstatica.h"
#include "acoes.h"

/*Funcao Principal*/
int principalEstatica();



#endif // CLIENTEESTATICA_H_INCLUDED
