#ifndef ACOES_H_INCLUDED
#define ACOES_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

/*Limpa a tela*/
void cls(void);

/*Pausa a tela*/
void pause(void);

/*Função que imprime o menu principal do programa*/
void imprime_menu(char *titulo);


#endif // ACOES_H_INCLUDED
